"Hello this is a parser for ***http://mymd.ae/listing/doctor***

To run this program you need to open /dist/parser/parser.exe.
Output excel file will be in /dist/parser/excel/ folder.

When you launch this program, you need to setup some properties :)

    1) Name your output file, e.g. (ParsedData). Don`t worry, it will be in .xls format.
    2) Type timeouts in seconds between every 8 parsed doctors(15 e.g.). It needs to prevent from bans on site.
        20 seconds by default. Min 5 sec. Max 60 sec. Or press ENTER. Parameters will pass automatically.
    3) Type page number, where are you want to start. 0 - its the first page, 1 - its the second page etc.
    4) Type page number, where are you want to stop. Or see total pages below.

Remember! You can skip 3) and 4) points. Just press ENTER twice. Parameters will pass automatically.
Remember! You always can type an interval of pages!

After end of parsing, in folder "excel" you will see your output file.